Bar chart dataset

- collected from 14 topics, 12 of which have 2 charts, while 2 topics have only 1 chart
- 581 summaries in total
- in the key-value pairs, the keys are bar references (single or multiple bar references), bar heights (exact or approximated), axis names, y axis units, references to the chart title, other references to chart-specific entities
- split in #summaries: train (378), validation (116), test (87)
- the splits are shuffled
- the dataset is not split according to topic/chart, but it could be
